Hidayathussibiyan Madarasa — Homepage only

Files:
index.html
css/style.css
js/script.js

The other pages are intentionally not created yet.
Add the real logo at images/logo.png when available.
